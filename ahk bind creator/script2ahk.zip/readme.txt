IF THE EXECUTABLE DOES NOT WORK, TROUBLESHOOT COMPATIBILITY (usually windows 8 or lower)

put the text you want to turn to successive binds into the input.txt file, or create it if it's not there.

Place the .cfg that was created in your tf\cfg folder, and when in tf2 type 

'exec (filename, no .cfg)' without the quotes.